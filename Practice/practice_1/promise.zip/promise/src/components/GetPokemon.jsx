import axios from "axios";
import { useEffect,useState } from "react";

const GetPokemon=()=>{
        return(
            <>
            
            
            </>
        )
}
export default GetPokemon